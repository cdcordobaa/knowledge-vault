#!/usr/bin/env python3
"""
Graph Builder — Extracts knowledge graph from wiki markdown frontmatter.
Wiki is source of truth. Graph is derived index. Always rebuildable.

Usage:
  python graph_builder.py                    # Build graph from wiki/
  python graph_builder.py --stats            # Build + show statistics
  python graph_builder.py --communities      # Build + detect communities
"""

import json
import os
import re
import sys
from pathlib import Path
from collections import defaultdict

WIKI_DIR = "wiki"
GRAPH_FILE = "graph/graph.json"
COMMUNITIES_FILE = "graph/communities.json"

# Edge types and their weights for retrieval scoring
EDGE_WEIGHTS = {
    "depends_on": 1.0,
    "generates": 1.0,
    "enables": 1.0,
    "blocks": 1.0,
    "cites": 0.9,
    "derived_from": 0.9,
    "contradicts": 0.8,
    "supersedes": 0.8,
    "measured_by": 0.7,
    "related_to": 0.4,
    "mentions": 0.2,
}


def parse_frontmatter(content):
    """Extract YAML frontmatter from markdown content."""
    if not content.startswith("---"):
        return {}, content
    end = content.find("---", 3)
    if end == -1:
        return {}, content
    fm_text = content[3:end].strip()
    body = content[end + 3:].strip()

    # Simple YAML parser for our specific format (avoids pyyaml dependency)
    fm = {}
    current_key = None
    current_list = None
    in_nested = None  # Track if we're inside a nested block like relations:
    nested_dict = None

    for line in fm_text.split("\n"):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        indent = len(line) - len(line.lstrip())

        # Detect end of nested block (back to top-level key)
        if in_nested and indent == 0 and ":" in stripped:
            fm[in_nested] = nested_dict
            in_nested = None
            nested_dict = None

        # Inside a nested block
        if in_nested and indent > 0:
            if ":" in stripped and not stripped.startswith("-"):
                key, _, value = stripped.partition(":")
                key = key.strip()
                value = value.strip()
                if value.startswith("[") and value.endswith("]"):
                    items = [i.strip().strip("'\"") for i in value[1:-1].split(",") if i.strip()]
                    nested_dict[key] = items
                elif value == "" or value == "[]":
                    nested_dict[key] = []
                    current_key = key
                else:
                    nested_dict[key] = value.strip("'\"")
            elif stripped.startswith("- ") and current_key and current_key in nested_dict:
                item = stripped[2:].strip().strip("'\"")
                if isinstance(nested_dict.get(current_key), list):
                    nested_dict[current_key].append(item)
            continue

        # Top-level key: value
        if ":" in stripped and not stripped.startswith("-"):
            key, _, value = stripped.partition(":")
            key = key.strip()
            value = value.strip()

            if value == "" or value == "[]":
                # Could be start of a list OR a nested block
                # Peek: if this is 'relations', treat as nested dict
                if key in ("relations",):
                    in_nested = key
                    nested_dict = {}
                    current_key = None
                else:
                    current_key = key
                    current_list = []
                    fm[key] = current_list
            elif value.startswith("[") and value.endswith("]"):
                items = [i.strip().strip("'\"") for i in value[1:-1].split(",") if i.strip()]
                fm[key] = items
                current_key = key
                current_list = None
            else:
                fm[key] = value.strip("'\"")
                current_key = key
                current_list = None
        elif stripped.startswith("- ") and current_key:
            item = stripped[2:].strip().strip("'\"")
            if isinstance(fm.get(current_key), list):
                fm[current_key].append(item)

    # Close any open nested block
    if in_nested and nested_dict is not None:
        fm[in_nested] = nested_dict

    return fm, body


def extract_wikilinks(body):
    """Extract [[wikilinks]] from markdown body text."""
    pattern = r'\[\[([^\]|]+?)(?:\|[^\]]+?)?\]\]'
    return list(set(re.findall(pattern, body)))


def normalize_id(page_path):
    """Convert file path to node ID."""
    return page_path.replace(WIKI_DIR + "/", "").replace(".md", "")


def extract_tldr(body):
    """Extract TLDR from page body."""
    for line in body.split("\n"):
        line = line.strip()
        if line.startswith("> **TLDR:**") or line.startswith("> **TLDR**:"):
            return line.replace("> **TLDR:**", "").replace("> **TLDR**:", "").strip()
    return ""


def build_graph():
    """Scan wiki/ and build the knowledge graph."""
    nodes = {}
    edges = []

    # Scan all markdown files
    for root, dirs, files in os.walk(WIKI_DIR):
        # Skip special files
        for fname in files:
            if not fname.endswith(".md"):
                continue
            if fname in ("index.md", "log.md"):
                continue

            filepath = os.path.join(root, fname)
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()

            fm, body = parse_frontmatter(content)
            node_id = normalize_id(filepath)

            # Create node
            relations_block = fm.get("relations", {})
            if not isinstance(relations_block, dict):
                relations_block = {}
            cites_list = relations_block.get("cites", fm.get("cites", []))
            if isinstance(cites_list, str):
                cites_list = [cites_list]
            if not isinstance(cites_list, list):
                cites_list = []

            nodes[node_id] = {
                "id": node_id,
                "path": filepath,
                "type": fm.get("type", "unknown"),
                "tldr": extract_tldr(body),
                "confidence": fm.get("confidence", "medium"),
                "source_count": len(cites_list),
                "aliases": fm.get("aliases", []),
            }

            # Extract typed edges from relations
            relations = fm.get("relations", {})
            if not isinstance(relations, dict):
                relations = {}
            for edge_type in EDGE_WEIGHTS:
                if edge_type == "mentions":
                    continue  # handled below from wikilinks
                targets = relations.get(edge_type, [])
                if isinstance(targets, str):
                    targets = [targets]
                if not isinstance(targets, list):
                    targets = []
                for target in targets:
                    if target:
                        target_clean = target.strip().replace(" ", "_").lower()
                        edges.append({
                            "source": node_id,
                            "target": target_clean,
                            "type": edge_type,
                            "weight": EDGE_WEIGHTS[edge_type],
                        })

            # Extract wikilinks as MENTIONS edges
            wikilinks = extract_wikilinks(body)
            for link in wikilinks:
                link_normalized = link.strip().replace(" ", "_").lower()
                # Don't create MENTIONS if a stronger typed edge already exists
                existing_targets = {e["target"] for e in edges
                                   if e["source"] == node_id and e["type"] != "mentions"}
                if link_normalized not in existing_targets:
                    edges.append({
                        "source": node_id,
                        "target": link_normalized,
                        "type": "mentions",
                        "weight": EDGE_WEIGHTS["mentions"],
                    })

    # Build graph structure
    graph = {
        "nodes": nodes,
        "edges": edges,
        "metadata": {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "edge_types": dict(defaultdict(int)),
            "built_at": __import__("datetime").datetime.now().isoformat(),
        }
    }

    # Count edge types
    for e in edges:
        graph["metadata"]["edge_types"][e["type"]] = \
            graph["metadata"]["edge_types"].get(e["type"], 0) + 1

    # Save
    os.makedirs(os.path.dirname(GRAPH_FILE), exist_ok=True)
    with open(GRAPH_FILE, "w") as f:
        json.dump(graph, f, indent=2)

    return graph


def detect_communities(graph):
    """Simple community detection using connected components + modularity.
    For production, use networkx Louvain. This is a lightweight version."""
    adjacency = defaultdict(set)
    for edge in graph["edges"]:
        adjacency[edge["source"]].add(edge["target"])
        adjacency[edge["target"]].add(edge["source"])

    # Connected components as basic communities
    visited = set()
    communities = []

    def bfs(start):
        queue = [start]
        component = set()
        while queue:
            node = queue.pop(0)
            if node in visited:
                continue
            visited.add(node)
            component.add(node)
            for neighbor in adjacency.get(node, set()):
                if neighbor not in visited:
                    queue.append(neighbor)
        return component

    for node_id in graph["nodes"]:
        if node_id not in visited:
            component = bfs(node_id)
            if component:
                communities.append(sorted(list(component)))

    # Find bridge nodes (appear in edges between communities)
    node_to_community = {}
    for i, comm in enumerate(communities):
        for node in comm:
            node_to_community[node] = i

    bridges = set()
    for edge in graph["edges"]:
        src_comm = node_to_community.get(edge["source"], -1)
        tgt_comm = node_to_community.get(edge["target"], -1)
        if src_comm != tgt_comm and src_comm >= 0 and tgt_comm >= 0:
            bridges.add(edge["source"])
            bridges.add(edge["target"])

    result = {
        "communities": [
            {"id": i, "members": comm, "size": len(comm)}
            for i, comm in enumerate(communities)
        ],
        "bridge_nodes": sorted(list(bridges)),
        "isolated_nodes": [n for n in graph["nodes"] if n not in adjacency],
        "community_count": len(communities),
    }

    with open(COMMUNITIES_FILE, "w") as f:
        json.dump(result, f, indent=2)

    return result


def print_stats(graph, communities=None):
    """Print graph statistics."""
    meta = graph["metadata"]
    print(f"\n{'='*50}")
    print(f"WIKI MEMORY GRAPH — {meta['built_at']}")
    print(f"{'='*50}")
    print(f"Nodes: {meta['node_count']}")
    print(f"Edges: {meta['edge_count']}")
    print(f"\nEdge types:")
    for etype, count in sorted(meta["edge_types"].items(), key=lambda x: -x[1]):
        print(f"  {etype}: {count}")

    if communities:
        print(f"\nCommunities: {communities['community_count']}")
        for c in communities["communities"]:
            print(f"  Cluster {c['id']}: {c['size']} nodes — {', '.join(c['members'][:5])}{'...' if len(c['members']) > 5 else ''}")
        if communities["bridge_nodes"]:
            print(f"\nBridge nodes: {', '.join(communities['bridge_nodes'])}")
        if communities["isolated_nodes"]:
            print(f"Isolated nodes: {', '.join(communities['isolated_nodes'])}")


if __name__ == "__main__":
    graph = build_graph()

    if "--communities" in sys.argv or "--stats" in sys.argv:
        communities = detect_communities(graph)
        print_stats(graph, communities)
    elif len(sys.argv) == 1:
        print(f"Graph built: {graph['metadata']['node_count']} nodes, {graph['metadata']['edge_count']} edges → {GRAPH_FILE}")
    else:
        print_stats(graph)
