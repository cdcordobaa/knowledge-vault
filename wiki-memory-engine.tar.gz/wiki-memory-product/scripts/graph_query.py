#!/usr/bin/env python3
"""
Graph Query — Find relevant wiki pages by traversing the knowledge graph.
Replaces sequential index scanning with relational retrieval.

Usage:
  python graph_query.py "<keywords>"                    # Find relevant nodes
  python graph_query.py path "<entity_a>" "<entity_b>"  # Shortest path
  python graph_query.py neighbors "<entity>"             # Direct connections
  python graph_query.py gaps                             # Find structural holes
"""

import json
import os
import sys
from collections import defaultdict, deque

GRAPH_FILE = "graph/graph.json"
COMMUNITIES_FILE = "graph/communities.json"


def load_graph():
    if not os.path.exists(GRAPH_FILE):
        print("NO GRAPH FOUND. Run: python scripts/graph_builder.py")
        sys.exit(1)
    with open(GRAPH_FILE, "r") as f:
        return json.load(f)


def fuzzy_match(query_terms, text):
    """Score how well query terms match a text."""
    text_lower = text.lower()
    score = 0
    for term in query_terms:
        term_lower = term.lower()
        if term_lower in text_lower:
            score += 1.0
        elif any(term_lower in word for word in text_lower.split("_")):
            score += 0.5
    return score


def cmd_query(keywords_str):
    """Find relevant nodes by keyword matching + graph expansion."""
    graph = load_graph()
    query_terms = keywords_str.lower().split()

    # Step 1: Score all nodes by keyword match
    scored = []
    for node_id, node in graph["nodes"].items():
        score = 0
        score += fuzzy_match(query_terms, node_id) * 2.0  # ID match = strong
        score += fuzzy_match(query_terms, node.get("tldr", "")) * 1.0
        score += fuzzy_match(query_terms, node.get("type", "")) * 0.5
        for alias in node.get("aliases", []):
            score += fuzzy_match(query_terms, alias) * 1.5
        if score > 0:
            scored.append((node_id, score))

    scored.sort(key=lambda x: -x[1])
    seed_nodes = [s[0] for s in scored[:5]]  # Top 5 matches

    if not seed_nodes:
        print("NO MATCHES FOUND. Try different keywords.")
        return

    # Step 2: Expand to 2-hop neighborhood
    adjacency = defaultdict(list)
    for edge in graph["edges"]:
        adjacency[edge["source"]].append(edge)
        adjacency[edge["target"]].append({
            **edge,
            "source": edge["target"],
            "target": edge["source"],
        })

    expanded = {}  # node_id → (score, hop_distance, connecting_edges)
    for seed in seed_nodes:
        base_score = dict(scored).get(seed, 0)
        expanded[seed] = {"score": base_score, "hops": 0, "edges": []}

        # 1-hop
        for edge in adjacency.get(seed, []):
            neighbor = edge["target"]
            edge_score = base_score * edge["weight"] * 0.7  # Decay
            if neighbor not in expanded or expanded[neighbor]["score"] < edge_score:
                expanded[neighbor] = {
                    "score": edge_score,
                    "hops": 1,
                    "edges": [f"{seed} --{edge['type']}--> {neighbor}"]
                }

            # 2-hop
            for edge2 in adjacency.get(neighbor, []):
                hop2 = edge2["target"]
                hop2_score = edge_score * edge2["weight"] * 0.5
                if hop2 not in expanded or expanded[hop2]["score"] < hop2_score:
                    expanded[hop2] = {
                        "score": hop2_score,
                        "hops": 2,
                        "edges": [
                            f"{seed} --{edge['type']}--> {neighbor}",
                            f"{neighbor} --{edge2['type']}--> {hop2}"
                        ]
                    }

    # Step 3: Rank and output
    ranked = sorted(expanded.items(), key=lambda x: -x[1]["score"])[:15]

    print(f"QUERY: \"{keywords_str}\"")
    print(f"FOUND: {len(ranked)} relevant nodes\n")

    for node_id, info in ranked:
        node = graph["nodes"].get(node_id, {})
        tldr = node.get("tldr", "(no TLDR)")
        hops = info["hops"]
        score = info["score"]
        node_type = node.get("type", "?")
        path_info = node.get("path", "?")

        hop_label = {0: "DIRECT", 1: "1-hop", 2: "2-hop"}[hops]
        print(f"  [{hop_label}] {node_id} ({node_type}) — score: {score:.2f}")
        print(f"    TLDR: {tldr[:120]}")
        print(f"    Path: {path_info}")
        if info["edges"]:
            print(f"    Via: {' → '.join(info['edges'])}")
        print()


def cmd_path(entity_a, entity_b):
    """Find shortest path between two entities."""
    graph = load_graph()

    adjacency = defaultdict(list)
    for edge in graph["edges"]:
        adjacency[edge["source"]].append((edge["target"], edge["type"]))
        adjacency[edge["target"]].append((edge["source"], edge["type"]))

    # Normalize inputs
    entity_a = entity_a.lower().replace(" ", "_")
    entity_b = entity_b.lower().replace(" ", "_")

    # Find closest matching node IDs
    def find_node(query):
        for nid in graph["nodes"]:
            if query in nid.lower():
                return nid
        return None

    start = find_node(entity_a)
    end = find_node(entity_b)

    if not start:
        print(f"NOT FOUND: {entity_a}")
        return
    if not end:
        print(f"NOT FOUND: {entity_b}")
        return

    # BFS shortest path
    queue = deque([(start, [(start, "")])])
    visited = {start}

    while queue:
        current, path = queue.popleft()
        if current == end:
            print(f"PATH: {start} → {end} ({len(path)-1} hops)\n")
            for i, (node, edge_type) in enumerate(path):
                prefix = "  " * i
                if edge_type:
                    print(f"{prefix}--{edge_type}-->")
                tldr = graph["nodes"].get(node, {}).get("tldr", "")
                print(f"{prefix}[{node}] {tldr[:80]}")
            return

        for neighbor, edge_type in adjacency.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [(neighbor, edge_type)]))

    print(f"NO PATH between {start} and {end}")


def cmd_neighbors(entity):
    """Show all direct connections of an entity."""
    graph = load_graph()
    entity = entity.lower().replace(" ", "_")

    # Find node
    node_id = None
    for nid in graph["nodes"]:
        if entity in nid.lower():
            node_id = nid
            break

    if not node_id:
        print(f"NOT FOUND: {entity}")
        return

    node = graph["nodes"][node_id]
    print(f"NEIGHBORS OF: {node_id}")
    print(f"TLDR: {node.get('tldr', '(none)')}\n")

    outbound = [e for e in graph["edges"] if e["source"] == node_id]
    inbound = [e for e in graph["edges"] if e["target"] == node_id]

    if outbound:
        print("OUTBOUND:")
        for e in outbound:
            target_node = graph["nodes"].get(e["target"], {})
            tldr = target_node.get("tldr", "")
            print(f"  --{e['type']}--> {e['target']}: {tldr[:80]}")

    if inbound:
        print("\nINBOUND:")
        for e in inbound:
            source_node = graph["nodes"].get(e["source"], {})
            tldr = source_node.get("tldr", "")
            print(f"  <--{e['type']}-- {e['source']}: {tldr[:80]}")

    if not outbound and not inbound:
        print("  (isolated — no connections)")


def cmd_gaps():
    """Find structural holes in the graph."""
    graph = load_graph()

    if not os.path.exists(COMMUNITIES_FILE):
        print("No communities file. Run: python scripts/graph_builder.py --communities")
        return

    with open(COMMUNITIES_FILE, "r") as f:
        communities = json.load(f)

    # Find pairs of communities with no cross-edges
    node_to_comm = {}
    for comm in communities["communities"]:
        for member in comm["members"]:
            node_to_comm[member] = comm["id"]

    cross_edges = defaultdict(set)
    for edge in graph["edges"]:
        src_comm = node_to_comm.get(edge["source"])
        tgt_comm = node_to_comm.get(edge["target"])
        if src_comm is not None and tgt_comm is not None and src_comm != tgt_comm:
            pair = tuple(sorted([src_comm, tgt_comm]))
            cross_edges[pair].add(edge["source"])
            cross_edges[pair].add(edge["target"])

    n_comms = len(communities["communities"])
    print(f"STRUCTURAL GAPS IN {n_comms} COMMUNITIES:\n")

    disconnected_pairs = []
    for i in range(n_comms):
        for j in range(i + 1, n_comms):
            if (i, j) not in cross_edges:
                comm_i = communities["communities"][i]
                comm_j = communities["communities"][j]
                disconnected_pairs.append((comm_i, comm_j))

    if disconnected_pairs:
        for ci, cj in disconnected_pairs:
            print(f"  GAP: Community {ci['id']} ({', '.join(ci['members'][:3])}) <-?-> "
                  f"Community {cj['id']} ({', '.join(cj['members'][:3])})")
            print(f"    → What connects these domains?\n")
    else:
        print("  No structural gaps found — all communities are connected.")

    if communities["isolated_nodes"]:
        print(f"\nISOLATED NODES (not in any community):")
        for node in communities["isolated_nodes"]:
            print(f"  • {node}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "path" and len(sys.argv) >= 4:
        cmd_path(sys.argv[2], sys.argv[3])
    elif cmd == "neighbors" and len(sys.argv) >= 3:
        cmd_neighbors(sys.argv[2])
    elif cmd == "gaps":
        cmd_gaps()
    else:
        cmd_query(" ".join(sys.argv[1:]))
